﻿===========================================================
  PEACE TV APPS SUITE - ALL-IN-ONE BUNDLE PACK (ANDROID TV)
===========================================================

Included Applications in this Package:
1. TvHome-release.apk   -> Peace Launcher (Ultra-fast, zero-ads Android TV Launcher)
2. Browser-release.apk  -> Peace Browser (Ad-shielded, remote-optimized TV Web Browser)
3. TVFileBox.apk        -> Peace File Manager (Lightweight TV File Manager)
4. SmartTube.apk        -> SmartTube (Ad-free, 4K YouTube player for Android TV)
5. SendFilesToTV.apk    -> Send Files to TV (Fast wireless file sharing mobile/PC to TV)

-----------------------------------------------------------
HOW TO INSTALL ON ANY ANDROID TV (STEP-BY-STEP):
-----------------------------------------------------------
1. Enable 'Unknown Sources':
   - Go to TV Settings -> Device Preferences / Security -> Unknown sources -> Allow.

2. Install Peace Launcher first:
   - Sideload and install 'TvHome-release.apk'.
   - Press HOME and select Peace Launcher ('Always').

3. First-Time Setup Wizard:
   - On the first open, Peace Launcher automatically opens the Setup Wizard.
   - Enter your shared Google Photos Album URL (or keep the default 4K curated album).
   - Tap 'Install All Apps' to install Peace Browser, File Manager, and SmartTube directly!

Enjoy your lightning fast, ad-free, beautiful Android TV experience!
